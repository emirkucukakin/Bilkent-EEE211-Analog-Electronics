# Lab 04 — IF amplifier simulations

Open an ASC schematic in LTspice and run it. Keep the local ASY symbols and devices.lib alongside the schematics. Each CIR file contains the same circuit as a standalone SPICE deck. The stage models use the component values and KSP10TA parameters from the report.

| File prefix | Circuit |
| --- | --- |
| Stage1 | Q50, with collector node c5 and base b5 |
| Stage2 | Q60, with collector node c6 and base b6 |
| Cascade | Both stages, connected through C52 |

Bias files calculate the DC operating point. Zin files inject a 1 A AC test current, so the linear magnitude of V(vin) gives the input impedance in ohms. Gain files use a 50 ohm generator and a 20 pF probe at each observed collector. Plot V(c5)/V(vin) or V(c6)/V(vin) in dB. Read the middle AC point at 15.003 MHz. The cascade impedance test includes both probe loads. The 1 teraohm resistors provide a DC reference for otherwise floating, capacitively coupled nodes.

The companion IF_results.csv contains the independent ngspice run. The standalone gains were 30.82 and 34.91 dB. Loading stage one with stage two reduced the first-stage gain to 19.26 dB. Overall gain was 54.13 dB.
