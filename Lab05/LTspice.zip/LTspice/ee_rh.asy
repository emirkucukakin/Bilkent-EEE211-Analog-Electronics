Version 4
SymbolType CELL
LINE Normal 0 0 16 0
LINE Normal 16 0 20 -8
LINE Normal 20 -8 28 8
LINE Normal 28 8 36 -8
LINE Normal 36 -8 44 8
LINE Normal 44 8 52 -8
LINE Normal 52 -8 60 8
LINE Normal 60 8 68 -8
LINE Normal 68 -8 76 8
LINE Normal 76 8 80 0
LINE Normal 80 0 96 0
WINDOW 0 48 -40 Center 2
WINDOW 3 48 -18 Center 2
SYMATTR Prefix R
PIN 0 0 NONE 0
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN 96 0 NONE 0
PINATTR PinName 2
PINATTR SpiceOrder 2
