# Lab 05 — Tuned transmitter simulations

Open Transmitter.asc and run the transient analysis. Keep the ASY symbols and devices.lib in this folder. Probe out for the 10 ohm load voltage and vc for the collector voltage. The CIR files provide the same circuits as standalone netlists. The tapped transformer uses 2.5 uH and 322 nH in series with positive coupling of 0.4. C37 is 120 pF.

The source amplitude in Transmitter.asc is 1.75 V peak before the 50 ohm source resistor. This is a reconstruction choice from the amplitude sweep. Drive_sweep.asc runs the same circuit at eleven input levels from 0.1 to 4 V peak. Each run lasts 5 us and saves the last 1 us.

Drive_sweep.csv summarizes independent ngspice transient runs using the same model parameters. Power is mean squared load voltage divided by 10 ohms over the last ten full periods. At 1.75 V peak drive the load reached 2.378 V peak-to-peak and 70.8 mW. Collector harmonic distortion includes harmonics 2 through 10 and provides a numerical aid for comparing waveform distortion at different drive levels.

The model cards use the electrical parameters of the 2N2222 and BC556B entries in the published LTspice standard.bjt listings (LTwiki and evenator/LTSpice-Libraries). Local model names TX2222 and TX556B keep the parameter sets explicit.
